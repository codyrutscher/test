class HomeController < ApplicationController
  def index
  end

  def about
  end

  def pricing
  end
end
